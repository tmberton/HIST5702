<?php

$libraryType = 'user'; //user or group
$libraryID = 10150;
$librarySlug = '';
$apiKey = 'NiA0ZjtZaAP8S4VGaJsmPW96';
$collectionKey = '';
