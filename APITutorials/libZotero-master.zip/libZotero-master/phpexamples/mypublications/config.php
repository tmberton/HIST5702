<?php

$libraryType = ''; //user or group
$libraryID = ;
$librarySlug = '';
$collectionKey = '';
$apiKey = '';
