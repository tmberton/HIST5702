<?php

$libraryType = 'group'; //user or group
$libraryID = 729;
$librarySlug = 'all_things_zotero';
$apiKey = '';
$collectionKey = '';
