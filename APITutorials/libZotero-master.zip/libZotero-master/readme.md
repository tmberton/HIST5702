# libZotero #

A library to interact with the Zotero API ( http://www.zotero.org/support/dev/server_api ). This repository contains PHP, Python and javascript (reliant on jQuery) versions with similar interfaces. The PHP and javascript versions are slight modifications to the libraries used by zotero.org itself. The Python library is a nearly direct port of the PHP library.




