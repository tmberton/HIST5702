<?php

$libraryType = 'user'; //user or group
$userID = 0;
$userSlug = '<slug>';
$apiKey = '<apikey>';

