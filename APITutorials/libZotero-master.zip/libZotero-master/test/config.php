<?php

$libraryType = 'user'; //user or group
$libraryID = 0;
$librarySlug = '';
$apiKey = '';
$addKeyAtProxy = true;//add @apiKey to requests at the php proxy so JS doesn't need a copy of it

