
var zConfig = {
    libraryType: '',
    userID: 0,
    libraryID: 0,
    userSlug: '',
    apiKey: ''
}
