<?php
namespace Zotero;

 /**
  * Explicit mappings for Zotero
  *
  * @package    libZotero
  */
class Mappings
{
    public $itemTypes = array();
    public $itemFields = array();
    public $itemTypeCreatorTypes = array();
    public $creatorFields = array();
    
    
}

?>