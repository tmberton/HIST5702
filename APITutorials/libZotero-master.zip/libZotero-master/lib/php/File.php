<?php
namespace Zotero;

class File
{
    
}
