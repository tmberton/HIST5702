<?php
namespace Zotero;

/**
 * Zotero specific exception class with no added functionality
 * 
 * @package libZotero
 */
class Exception extends \Exception
{
    
}
?>