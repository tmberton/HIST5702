from distutils.core import setup
setup(name='libZotero',
      version='0.2.5',
      description='Python module for interacting with the zotero.org API',
      author='Faolan Cheslack-Postava',
      url='https://github.com/fcheslack/libZotero',
      packages=['libZotero'],
      )
